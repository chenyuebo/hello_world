package cn.com.sina.guide;

import android.app.Activity;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

import cn.com.sina.guide.target.Target;
import cn.com.sina.guide.utils.ScreenUtils;

/**
 * Created by penghao on 2017/10/23.
 */

public abstract class GuideView extends View {

    private List<Target> mTargets;

    protected GestureDetector detector;

    protected int screenWidth, screenHeight;

    public GuideView(Context context) {
        super(context);
        baseInit();
    }

    public GuideView(Context context, AttributeSet attrs) {
        super(context, attrs);
        baseInit();
    }

    public GuideView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        baseInit();
    }

    private void baseInit() {
        screenWidth = ScreenUtils.getScreenWidth(getContext());
        screenHeight = ScreenUtils.getScreenHeight(getContext());
        initDetector();
    }

    private void initDetector() {
        detector = new GestureDetector(getContext(), new GestureDetector.OnGestureListener() {
            @Override
            public boolean onDown(MotionEvent e) {
                int x = (int) e.getX();
                int y = (int) e.getY();
                if (!canTouchOutSide() && touchInViews(x, y)) {
                    dismiss();
                } else if (canTouchOutSide()) {
                    dismiss();
                }
                return true;
            }

            @Override
            public void onShowPress(MotionEvent e) {
            }

            @Override
            public boolean onSingleTapUp(MotionEvent e) {
                return true;
            }

            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                return false;
            }

            @Override
            public void onLongPress(MotionEvent e) {
            }

            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                return false;
            }
        });
    }

    private boolean touchInViews(int x, int y) {
        if (mTargets == null) {
            return false;
        }
        for (Target target : mTargets) {
            if (target.getRect().contains(x, y)) {
                return true;
            }
        }
        return false;

    }

    public void setTargets(List<Target> targets) {
        mTargets = targets;
    }

    public void addTarget(Target target) {
        if (mTargets == null) {
            mTargets = new ArrayList<>();
        }
        mTargets.add(target);
        invalidate();
    }

    /**
     * 是否可以点击目标Views外区域
     */
    protected abstract boolean canTouchOutSide();

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return detector.onTouchEvent(event);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (mTargets == null) {
            return;
        }
        for (Target target : mTargets) {
            target.draw(canvas);
        }
    }

    public void dismiss() {
        if (getParent() instanceof ViewGroup) {
            setVisibility(GONE);
            ((ViewGroup) getParent()).removeView(this);
        }
    }

    public void show(Activity activity) {
        if(isShown()){
            return;
        }
        if (activity != null && !activity.isFinishing()) {
            ViewGroup viewGroup = (ViewGroup) activity.findViewById(android.R.id.content);
            if (viewGroup != null && getParent() == null) {
                ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
                setId(R.id.finance_app_guide_view);
                viewGroup.addView(GuideView.this, layoutParams);
                setVisibility(VISIBLE);
            }
        }
    }

}

