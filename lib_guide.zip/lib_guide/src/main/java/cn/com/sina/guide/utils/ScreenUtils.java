package cn.com.sina.guide.utils;

import android.content.Context;
import android.view.Display;
import android.view.WindowManager;

import java.lang.reflect.Field;

/**
 * @Author penghao
 * @Date 2017/10/25
 */

public class ScreenUtils {

    public static int getScreenHeight(Context context) {
        Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        return display.getHeight();
    }

    public static int getScreenWidth(Context context) {
        Display display = ((WindowManager) context.getSystemService(Context.WINDOW_SERVICE)).getDefaultDisplay();
        return display.getWidth();
    }


    public static int getStatusHeight(Context context) {
        Class<?> c;
        Object obj;
        Field field;
        int x, sbar;
        try {
            c = Class.forName("com.android.internal.R$dimen");
            obj = c.newInstance();
            field = c.getField("status_bar_height");
            x = Integer.parseInt(field.get(obj).toString());
            sbar = context.getResources().getDimensionPixelSize(x);
        } catch (Exception e1) {
            sbar = 0;
        }
        return sbar;
    }
}
