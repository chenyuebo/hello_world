package cn.com.sina.guide.utils;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Set;


/**
 * 引导和新手教学sp
 */
public class SpGuideUtils {
    private static final String SinaFinance_Config = "SinaFinance_Guid";
    private static Context mcontext = null;
    public static final String GUIDE_NOTIFY_SETTING = "guide_open_notify";

    public static void init(Context context) {
        mcontext = context;
    }

    public static boolean getBooleanSharedPreferences(GuideType key, boolean defValue) {
        try {
            SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
            return settings.getBoolean(key.toString(), defValue);
        } catch (ClassCastException e) {
            return defValue;
        }
    }

    public static Set<String> getStringSetSharedPreferences(String key, Set<String> defValue) {

        try {
            SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
            return settings.getStringSet(key, defValue);
        } catch (ClassCastException e) {
            return defValue;
        }
    }

    public static void setStringSetSharedPreferences(String key, Set<String> value) {
        if (key != null) {
            SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putStringSet(key, value);
            editor.apply();
        }
    }

    public static void setString(String key, String value) {
        if (key != null) {
            SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
            SharedPreferences.Editor editor = settings.edit();
            editor.putString(key, value);
            editor.apply();
        }
    }

    public static String getString(String key, String defValue) {
        if (key != null) {
            SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
            return settings.getString(key, defValue);
        }
        return null;
    }

    public static void clear() {
        SharedPreferences settings = mcontext.getSharedPreferences(SinaFinance_Config, 0);
        settings.edit().clear().apply();
    }
}
