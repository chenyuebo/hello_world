package cn.com.sina.guide.utils;

import android.app.Activity;
import android.view.View;
import android.view.ViewTreeObserver;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

import cn.com.sina.guide.GuideView;
import cn.com.sina.guide.R;
import cn.com.sina.guide.target.Target;
import cn.com.sina.guide.target.ViewTarget;

/**
 * @Author penghao
 * @Date 2017/11/20
 */

public class GuideUtils {

    private Activity mActivity;

    private GuideView mGuideView;

    private Set<String> mGuideList;

    private String KEY = "finance_guide_list";

    public GuideUtils(Activity activity) {
        this.mActivity = activity;
        this.mGuideList = new HashSet<>(SpGuideUtils.getStringSetSharedPreferences(KEY, new HashSet<String>()));
    }

    public void showGuide(final List<Target> targets, GuideType key) {
        Boolean hasShow = mGuideList.contains(key.toString());
        if (!hasShow) {
            if (mGuideView == null) {
                mGuideView = new GuideView(mActivity) {
                    @Override
                    protected boolean canTouchOutSide() {
                        return true;
                    }
                };
            }
            if (targets != null && targets.size() > 0) {
                for (final Target target : targets) {
                    if (target instanceof ViewTarget) {
                        final ViewTarget viewTarget = (ViewTarget) target;
                        ViewTreeObserver observer = viewTarget.getView().getViewTreeObserver();
                        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                if (mGuideView.isShown()) {
                                    mGuideView.addTarget(target);
                                }
                                viewTarget.getView().getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            }
                        });
                    } else {
                        mGuideView.addTarget(target);
                    }
                }
            }
            mGuideView.show(mActivity);
            mGuideList.add(key.toString());
            SpGuideUtils.setStringSetSharedPreferences(KEY, mGuideList);
        }
    }

    public void showGuide(final Target target, GuideType key) {
        Boolean hasShow = mGuideList.contains(key.toString());
        if (!hasShow) {
            if (mGuideView == null) {
                mGuideView = new GuideView(mActivity) {
                    @Override
                    protected boolean canTouchOutSide() {
                        return true;
                    }
                };
            }
            if (target != null) {
                if (target instanceof ViewTarget) {
                    final ViewTarget viewTarget = (ViewTarget) target;
                    if (viewTarget.getView() != null) {
                        ViewTreeObserver observer = viewTarget.getView().getViewTreeObserver();
                        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                if (mGuideView.isShown()) {
                                    mGuideView.addTarget(target);
                                }
                                viewTarget.getView().getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            }
                        });
                    }
                } else {
                    mGuideView.addTarget(target);
                }
            }
            mGuideView.show(mActivity);
            mGuideList.add(key.toString());
            SpGuideUtils.setStringSetSharedPreferences(KEY, mGuideList);
        }
    }

    public void addTarget(final List<Target> targets) {
        if (mGuideView != null && mGuideView.isShown()) {
            if (targets != null && targets.size() > 0) {
                for (final Target target : targets) {
                    if (target instanceof ViewTarget) {
                        final ViewTarget viewTarget = (ViewTarget) target;
                        ViewTreeObserver observer = viewTarget.getView().getViewTreeObserver();
                        observer.addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                            @Override
                            public void onGlobalLayout() {
                                if (mGuideView.isShown()) {
                                    mGuideView.addTarget(viewTarget);
                                }
                                viewTarget.getView().getViewTreeObserver().removeGlobalOnLayoutListener(this);
                            }
                        });
                    } else {
                        if (mGuideView.isShown()) {
                            mGuideView.addTarget(target);
                        }
                    }
                }
            }
        }
    }

    public boolean hasShow(GuideType key) {
        if (mGuideList == null) {
            return false;
        } else {
            return mGuideList.contains(key.toString());
        }
    }

    public GuideView getGuideView() {
        return mGuideView;
    }

    public void dismissGuide() {
        if (mGuideView != null) {
            mGuideView.dismiss();
        }
    }

    public static boolean showingGuide(Activity activity) {
        if (activity == null) {
            return true;
        }
        View guide = activity.findViewById(R.id.finance_app_guide_view);
        return guide != null;
    }
}
