package cn.com.sina.guide.utils;

/**
 * Created by jiangtao8 on 17/11/22.
 */

public enum GuideType {
    GUIDE_HQ_FUND_TAB, //行情基金页tab滑动
    GUIDE_FUND_DETAIL  //基金详情页每日净值，增长率
}
